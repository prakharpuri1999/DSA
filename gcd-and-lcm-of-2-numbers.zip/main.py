# GCD AND LCM OF AN ARRAY
def gcd(x,y):
    while y:
        x,y=y,x%y
    return x
x,y=map(int,input().split())
GCD=gcd(x,y)
print("LCM OF NUMBERS:",(x*y)//GCD)
print("GCD OF NUMBERS:",GCD)