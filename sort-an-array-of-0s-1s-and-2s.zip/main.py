# Sort an array of 0s 1s and 2s
def sort_array(arr,n):
    l=0
    mid=0
    high=n-1
    while mid<=high:
        if arr[mid]==0:
            arr[l],arr[mid]=arr[mid],arr[l]
            mid+=1
            l+=1
        elif arr[mid]==1:
            mid+=1
        else:
            arr[mid],arr[high]=arr[high],arr[mid]
            high-=1
arr=[1,2,0,2,1,1,0,0,0,2,2,1,2,0]
n=len(arr)
sort_array(arr,n)
print(arr)