# Minimum element in stack
class stack:
    def __init__(self):
        self.s=[]
        self.minEle=None
    def push(self,x):
        if not self.s:
            self.s.append(x)
            self.minEle=x
        elif x<self.minEle:
            self.s.append(2*x-self.minEle)
            self.minEle=x
        else:
            self.s.append(x)
    def pop(self):
        if not self.s:
            return -1
        top=self.s.pop()
        if top<self.minEle:
            k=self.minEle
            self.minEle=2*k-top
            return k
        else:
            return top
    def getMin(self):
        if not self.s:
            return -1
        else:
            return self.minEle

qn=int(input())
arr=list(map(int,input().split()))
qi=1
a=0
stk=stack()
while qi<=qn:
    qt=arr[a]
    if qt==1:
        stk.push(arr[a+1])
        a+=2
    elif qt==2:
        print(stk.pop(),end=" ")
        a+=1
    else:
        print(stk.getMin(),end=" ")
        a+=1
    qi+=1