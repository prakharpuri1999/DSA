# GCD OF AN ARRAY
def find_gcd(x,y):
    while y:
        x,y=y,x%y
    return x
l1=[4,12,8]
n=len(l1)
if n==1:
    print(*l1)
elif n==2:
    print(find_gcd(l1[0],l1[1]))
else:
    num1=l1[0]
    num2=l1[1]
    gcd=find_gcd(num1,num2)
    for i in range(2,n):
        gcd=find_gcd(gcd,l1[i])
    print(gcd)